const mapOptions = {
  center: [59.968642, 30.317425],
  zoom: 17
}

const map = new L.map('map', mapOptions);
const layer = new L.TileLayer('https://api.maptiler.com/maps/streets-v2/{z}/{x}/{y}.png?key=StFld3NCrvag1TMtL9m1');

map.addLayer(layer);

const iconOptions = {
  iconUrl: './images/map_pin.svg',
  iconSize: [38, 50],
  iconAnchor: [19, 50]
}

const customIcon = L.icon(iconOptions);

var markerOptions = {
  clickable: true,
  draggable: true,
  icon: customIcon
}

const marker = L.marker({lat: 59.968392, lng: 30.317825}, markerOptions);

marker.addTo(map);
