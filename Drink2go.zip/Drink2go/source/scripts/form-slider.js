const sliderElement = document.getElementById('slider');
const input1 = document.querySelector('.filters__price-field--from');
const input2 = document.querySelector('.filters__price-field--to');

noUiSlider.create(sliderElement, {
  start: [0, 900],
    range: {
      'min': [0],
      'max': [1050]
    },
    step: 1,
    connect: true,
	format: {
		from: function(value) {
			return parseFloat(value);
		},
		to: function(value) {
			if (Number.isInteger(value)) {
				return value.toFixed(0);
			}
			return value.toFixed(0);
		}
	}
});

const initRangeSliders = slider.noUiSlider.on('update', function () {
	var range = slider.noUiSlider.get();
  input1.value=range[0];
  input2.value=range[1];
});

initRangeSliders();



