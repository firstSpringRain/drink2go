document.addEventListener("DOMContentLoaded", function () {
  const swiper = new Swiper(".swiper", {
    loop: true, // Зацикливание слайдов
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button",
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
  });
});
