const burgerButton = document.querySelector('.main-nav__toggle');
const menu = document.querySelector('.main-nav__list');

menu.classList.remove('main-nav__list--active');

burgerButton.addEventListener('click', function() {
  menu.classList.toggle('main-nav__list--active');
  burgerButton.classList.toggle('main-nav__toggle--active');
});
